var mcs_config = {
  "logLevel": "1",
  "logHTTP": true,
  "oAuthTokenEndPoint": "OAUTH_URL",
  "mobileBackend": {
    "name": "ZX_Backend",
    "baseUrl": "https://250B93301C00455B8D2EEDB4C1EBBE58.aucom-east-1.oraclecloud.com:443",
    "authentication": {
      "type": "basic",
      "basic": {
        "mobileBackendId": "2d8f903d-5fff-4903-b05c-0cbb3914fdd9",
        "anonymousKey": "MjUwQjkzMzAxQzAwNDU1QjhEMkVFREI0QzFFQkJFNThfTW9iaWxlQW5vbnltb3VzX0FQUElEOmU5YWY3YjBlLWNmYTctNGUwNS1hOTAyLWI5NzNkZDViY2E2Nw=="
      },
      "oauth": {
        "clientId": "d8b4b66f45cc408d95a399be9ac80110",
        "clientSecret": "6e0680a9-ac77-4ce5-97a7-49dade43aa29"
      },
      "facebook":{
        "appId": "YOUR_FACEBOOK_APP_ID",
        "mobileBackendId": "YOUR_BACKEND_ID",
        "anonymousKey": "ANONYMOUS_KEY",
        "scopes": "public_profile,user_friends,email,user_location,user_birthday"
      },
      "token":{
        "mobileBackendId": "YOUR_BACKEND_ID",
        "anonymousKey": "ANONYMOUS_KEY"
      }
    }
  },
  // "sync": {
  //   "periodicRefreshPolicy": "PERIODIC_REFRESH_POLICY_REFRESH_NONE",
  //   "policies": [
  //     {
  //       "path": '/mobile/custom/firstApi/tasks',
  //       "fetchPolicy": 'FETCH_FROM_SERVICE_ON_CACHE_MISS'
  //     },
  //     {
  //       "path": '/mobile/custom/secondApi/tasks',
  //     }
  //   ]
  // },
  "syncExpress": {
    "handler": "OracleRestHandler",
    "policies": [
      {
        "path": '/mobile/custom/firstApi/tasks/:id(\\d+)?',
      },
      {
        "path": '/mobile/custom/secondApi/tasks/:id(\\d+)?',
      }
    ]
  }
};
